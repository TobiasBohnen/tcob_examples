#version 450 core

layout(location = 0)in vec2 vertPos;
layout(location = 1)in vec4 vertColor;
layout(location = 2)in vec3 vertTexCoords;

layout(std140, binding = 0)uniform Globals
{
	mat4 camera;
	mat4 model;
	uvec2 view_size;
	ivec2 mouse_pos;
	bool debug; 
};

layout(location = 0)out VS_OUT
{
	vec4 Color;
	vec3 TexCoords;
} vs_out;

void main()
{
	vec4 pos = camera * model * vec4(vertPos.xy, 0.0, 1.0);
	gl_Position = vec4(((pos.x / view_size.x) * 2.0 - 1.0), (1.0 - 2.0 * (pos.y / view_size.y)), 0.0, 1.0);
	vs_out.Color = vertColor;
	vs_out.TexCoords = vertTexCoords;
}