#version 300 es
precision mediump float;
precision mediump int;

in vec2 vertPos;
in vec4 vertColor;
in vec3 vertTexCoords;

uniform Globals
{
	mat4 camera;
	uvec2 view_size;
	ivec2 mouse_pos;
	float time;
	bool debug; 
};

uniform Material
{
	vec4 matColor;
  float matPointSize;
};

out vec4 Color;
out vec3 TexCoords;

uniform float u_pointsize;

void main()
{
    vec4 pos = camera * vec4(vertPos.xy, 0.0, 1.0);
    gl_Position = vec4(((pos.x / float(view_size.x)) * 2.0 - 1.0), (1.0 - 2.0 * (pos.y / float(view_size.y))), 0.0, 1.0);
    Color = vertColor;
    TexCoords = vertTexCoords;
    gl_PointSize = matPointSize;
}
