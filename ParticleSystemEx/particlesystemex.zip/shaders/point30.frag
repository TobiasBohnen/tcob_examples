#version 300 es
precision mediump float;
precision highp sampler2DArray;

in vec4 Color;
in vec3 TexCoords;

out vec4 fragColor;

uniform sampler2DArray texture0;

void main()
{
    vec3 tex = vec3(TexCoords.x + gl_PointCoord.x, TexCoords.y + gl_PointCoord.y, TexCoords.z);
    fragColor = texture(texture0, tex) * Color;
}